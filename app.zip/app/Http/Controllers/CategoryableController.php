<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryableController extends Controller
{
    //
}
