<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductItemController extends Controller
{
    //
}
